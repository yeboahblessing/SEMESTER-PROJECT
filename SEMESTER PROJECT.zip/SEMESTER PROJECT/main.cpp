#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <sstream>
#include <limits>

using namespace std;

struct User {
    string username;
    string password;
    double balance;
};

vector<User> users;

User* current_user = NULL;

void registerUser(string username, string password) {
    User newUser;
    newUser.username = username;
    newUser.password = password;
    newUser.balance = 0.0;
    users.push_back(newUser);
    cout << "Registration successful." << endl;
}

User* loginUser(string username, string password) {
    for (vector<User>::iterator it = users.begin(); it != users.end(); ++it) {
        if (it->username == username && it->password == password) {
            return &(*it);
        }
    }
    return NULL;
}

void showBalance() {
    cout << "Your balance: " << current_user->balance << endl;
}

void transferMoney(double amount, User* recipient) {
    if (amount > 0 && current_user->balance >= amount) {
        int transactionID = rand() % 10000;
        int reference = rand() % 10000;
        double prevSenderBalance = current_user->balance;
        double prevRecipientBalance = recipient->balance;

        current_user->balance -= amount;
        recipient->balance += amount;

        cout << "Transfer successful." << endl;
        cout << "Amount of " << amount << " has been sent to " << recipient->username << endl;

        char transactionIDStr[10];
        char referenceStr[10];

        sprintf(transactionIDStr, "TX%d", transactionID);
        sprintf(referenceStr, "REF%d", reference);

        cout << "Transaction ID: " << transactionIDStr << endl;
        cout << "Reference: " << referenceStr << endl;
        cout << "Sender's Previous Balance: " << prevSenderBalance << endl;
        cout << "Recipient's Previous Balance: " << prevRecipientBalance << endl;
        cout << "Current Balance: " << current_user->balance << endl;
    } else {
        cout << "Insufficient balance." << endl;
    }
}

void receiveMoney(double amount) {
    current_user->balance += amount;
    cout << "Received money successfully." << endl;
}

void buyAirtime(double amount) {
    if (amount > 0 && current_user->balance >= amount) {
        current_user->balance -= amount;
        cout << "Airtime purchased successfully." << endl;
    } else {
        cout << "Insufficient balance." << endl;
    }
}

int main() {
    while (true) {
        cout << "1. Register\n2. Login\n3. Exit\n";
        int choice;
        cin >> choice;

        if (choice == 1) {
            string username, password;
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;
            registerUser(username, password);
        } else if (choice == 2) {
            string username, password;
            cout << "Enter username: ";
            cin >> username;
            cout << "Enter password: ";
            cin >> password;
            current_user = loginUser(username, password);
            if (current_user) {
                cout << "Login successful." << endl;
                while (current_user) {
                    cout << "1. Send Money\n2. Receive Money\n3. Check Balance\n4. Buy Airtime\n5. Logout\n";
                    int option;
                    cin >> option;
                    if (option == 1) {
                        cout << "Enter recipient username: ";
                        string recipientusername;
                        cin >> recipientusername;
                        double amount;
                        cout << "Enter amount to send: ";
                        cin >> amount;
                        User* recipient = NULL;
                        for (vector<User>::iterator it = users.begin(); it != users.end(); ++it) {
                            if (it->username == recipientusername) {
                                recipient = &(*it);
                                break;
                            }
                        }
                        transferMoney(amount, recipient);
                    } else if (option == 2) {
                        double amount;
                        cout << "Enter amount to receive: ";
                        cin >> amount;
                        receiveMoney(amount);
                    } else if (option == 3) {
                        showBalance();
                    } else if (option == 4) {
                        double amount;
                        cout << "Enter amount to buy airtime: ";
                        cin >> amount;
                        buyAirtime(amount);
                    } else if (option == 5) {
                        current_user = NULL;
                        cout << "Logged out." << endl;
                        break;
                    } else {
                        cout << "Invalid option." << endl;
                    }
                }
            } else {
                cout << "Invalid username or password." << endl;
            }
        } else if (choice == 3) {
            break;
        }
    }

    return 0;
}
